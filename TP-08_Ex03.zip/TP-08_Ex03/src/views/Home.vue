<script setup>
import TheWelcome from "@/components/TheWelcome.vue";
</script>

<template>
  <main>
    <div><h1>You're in Home Page</h1></div>
    <p>Well done🥰</p>
   <a href="http://localhost:3000"> <button>Back to Login</button></a>
  </main>
</template>
