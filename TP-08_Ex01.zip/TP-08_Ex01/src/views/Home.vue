<script setup>
import TheWelcome from '@/components/TheWelcome.vue'
</script>

<template>
  <main>
    <div> <h1>Home Page</h1></div>
  </main>
</template>
